<?php

    $db = [
        "host" => "localhost",
        "dbname" => "louizpr198_bitesight",
        "username" => "louizpr198_bitesight",
        "password" => "4oiBthUtV",
        "port"=> "",
    ];

?>