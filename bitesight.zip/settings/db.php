<?php
    $db=
    [
        "host" => "localhost",
        "dbname" => "bitesight",
        "username" => "root",
        "password" => "",
        "port" => "",
    ]

?>