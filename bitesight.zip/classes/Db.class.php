<?php

    class Db {

        private static $conn;

        // @return PDO connection
        // -> if exists -> return existing
        // -> if !exists -> return new PDO
        public static function getInstance() {
            if(file_exists("settings/config.php")) {
                include_once("settings/config.php");
            } else {
                include_once("../settings/config.php");
            }
            
            if( self::$conn == null ) {
                self::$conn = new PDO("mysql:host=".$db['host']."; dbname=".$db['dbname'],$db['username'],$db['password']);
                return self::$conn;
            } else {
                return self::$conn;
            }
        }

    }

?>