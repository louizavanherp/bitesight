<div class="confirmationBox confirmationBox__invitation">
    <p>Uitnodiging(en) verstuurd</p>
</div>