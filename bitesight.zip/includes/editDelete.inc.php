<div class="editBox__delete editBox">
    <div class="editBox__delete__content editBox__content">
        <a class='editBox__delete__content__delete editBox__content__btn' href="?id=<?php echo $_GET['id']; ?>&delete=<?php echo $_GET['stockId']; ?>">Weggooien</a>
        <a class='editBox__delete__content__cancel editBox__content__cancel' href="#">Annuleren</a>
    </div>
  </div>