<div class="editBox__eat editBox">
    <div class="editBox__eat__content editBox__content">
        <a class='editBox__eat__content__eat editBox__content__btn' href="?id=<?php echo $_GET['id']; ?>&delete=<?php echo $_GET['stockId']; ?>">Opgegeten</a>
        <a class='editBox__eat__content__cancel editBox__content__cancel' href="#">Annuleren</a>
    </div>
  </div>