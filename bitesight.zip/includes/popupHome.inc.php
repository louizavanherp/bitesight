<div class="popup popupHome">
          <!-- popup content -->
          <div class="popup-content">
            <div class="popup-header">
              <span class=close>&times;</span>
            </div>
            <a class="popup-addBtn popup-addBtnHome" href="?addHome=<?php echo $productId; ?>">Voeg toe</a>
          </div>       
  </div>



