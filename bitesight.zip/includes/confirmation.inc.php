<div class="confirmationBox confirmationBox__list">
    <a href="list.php">Toegevoegd aan boodschappenlijst</a>
</div>